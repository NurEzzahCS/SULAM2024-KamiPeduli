import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyAcHe1Tb6JdVf7d9oanNVWYRh6fG_RnPPI",
            authDomain: "kami-peduli-uo0g9w.firebaseapp.com",
            projectId: "kami-peduli-uo0g9w",
            storageBucket: "kami-peduli-uo0g9w.appspot.com",
            messagingSenderId: "618966835882",
            appId: "1:618966835882:web:6691bf49bfeab04f26a6d3"));
  } else {
    await Firebase.initializeApp();
  }
}
