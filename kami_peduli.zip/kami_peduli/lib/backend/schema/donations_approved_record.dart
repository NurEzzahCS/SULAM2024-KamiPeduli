import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DonationsApprovedRecord extends FirestoreRecord {
  DonationsApprovedRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "DonationName" field.
  String? _donationName;
  String get donationName => _donationName ?? '';
  bool hasDonationName() => _donationName != null;

  // "DonationItem" field.
  List<String>? _donationItem;
  List<String> get donationItem => _donationItem ?? const [];
  bool hasDonationItem() => _donationItem != null;

  // "DonationQty" field.
  List<int>? _donationQty;
  List<int> get donationQty => _donationQty ?? const [];
  bool hasDonationQty() => _donationQty != null;

  // "NGOname" field.
  String? _nGOname;
  String get nGOname => _nGOname ?? '';
  bool hasNGOname() => _nGOname != null;

  // "Status" field.
  bool? _status;
  bool get status => _status ?? false;
  bool hasStatus() => _status != null;

  void _initializeFields() {
    _donationName = snapshotData['DonationName'] as String?;
    _donationItem = getDataList(snapshotData['DonationItem']);
    _donationQty = getDataList(snapshotData['DonationQty']);
    _nGOname = snapshotData['NGOname'] as String?;
    _status = snapshotData['Status'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('DonationsApproved');

  static Stream<DonationsApprovedRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DonationsApprovedRecord.fromSnapshot(s));

  static Future<DonationsApprovedRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => DonationsApprovedRecord.fromSnapshot(s));

  static DonationsApprovedRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DonationsApprovedRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DonationsApprovedRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DonationsApprovedRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DonationsApprovedRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DonationsApprovedRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDonationsApprovedRecordData({
  String? donationName,
  String? nGOname,
  bool? status,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'DonationName': donationName,
      'NGOname': nGOname,
      'Status': status,
    }.withoutNulls,
  );

  return firestoreData;
}

class DonationsApprovedRecordDocumentEquality
    implements Equality<DonationsApprovedRecord> {
  const DonationsApprovedRecordDocumentEquality();

  @override
  bool equals(DonationsApprovedRecord? e1, DonationsApprovedRecord? e2) {
    const listEquality = ListEquality();
    return e1?.donationName == e2?.donationName &&
        listEquality.equals(e1?.donationItem, e2?.donationItem) &&
        listEquality.equals(e1?.donationQty, e2?.donationQty) &&
        e1?.nGOname == e2?.nGOname &&
        e1?.status == e2?.status;
  }

  @override
  int hash(DonationsApprovedRecord? e) => const ListEquality().hash([
        e?.donationName,
        e?.donationItem,
        e?.donationQty,
        e?.nGOname,
        e?.status
      ]);

  @override
  bool isValidKey(Object? o) => o is DonationsApprovedRecord;
}
