import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SurveyMiscItemRecord extends FirestoreRecord {
  SurveyMiscItemRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "MiscItem" field.
  String? _miscItem;
  String get miscItem => _miscItem ?? '';
  bool hasMiscItem() => _miscItem != null;

  // "MiscQty" field.
  int? _miscQty;
  int get miscQty => _miscQty ?? 0;
  bool hasMiscQty() => _miscQty != null;

  void _initializeFields() {
    _miscItem = snapshotData['MiscItem'] as String?;
    _miscQty = castToType<int>(snapshotData['MiscQty']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('SurveyMiscItem');

  static Stream<SurveyMiscItemRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SurveyMiscItemRecord.fromSnapshot(s));

  static Future<SurveyMiscItemRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SurveyMiscItemRecord.fromSnapshot(s));

  static SurveyMiscItemRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SurveyMiscItemRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SurveyMiscItemRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SurveyMiscItemRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SurveyMiscItemRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SurveyMiscItemRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSurveyMiscItemRecordData({
  String? miscItem,
  int? miscQty,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'MiscItem': miscItem,
      'MiscQty': miscQty,
    }.withoutNulls,
  );

  return firestoreData;
}

class SurveyMiscItemRecordDocumentEquality
    implements Equality<SurveyMiscItemRecord> {
  const SurveyMiscItemRecordDocumentEquality();

  @override
  bool equals(SurveyMiscItemRecord? e1, SurveyMiscItemRecord? e2) {
    return e1?.miscItem == e2?.miscItem && e1?.miscQty == e2?.miscQty;
  }

  @override
  int hash(SurveyMiscItemRecord? e) =>
      const ListEquality().hash([e?.miscItem, e?.miscQty]);

  @override
  bool isValidKey(Object? o) => o is SurveyMiscItemRecord;
}
