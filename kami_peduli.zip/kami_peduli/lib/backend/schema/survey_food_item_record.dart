import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SurveyFoodItemRecord extends FirestoreRecord {
  SurveyFoodItemRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "FoodItem" field.
  String? _foodItem;
  String get foodItem => _foodItem ?? '';
  bool hasFoodItem() => _foodItem != null;

  // "FoodQty" field.
  int? _foodQty;
  int get foodQty => _foodQty ?? 0;
  bool hasFoodQty() => _foodQty != null;

  void _initializeFields() {
    _foodItem = snapshotData['FoodItem'] as String?;
    _foodQty = castToType<int>(snapshotData['FoodQty']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('SurveyFoodItem');

  static Stream<SurveyFoodItemRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SurveyFoodItemRecord.fromSnapshot(s));

  static Future<SurveyFoodItemRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SurveyFoodItemRecord.fromSnapshot(s));

  static SurveyFoodItemRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SurveyFoodItemRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SurveyFoodItemRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SurveyFoodItemRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SurveyFoodItemRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SurveyFoodItemRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSurveyFoodItemRecordData({
  String? foodItem,
  int? foodQty,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'FoodItem': foodItem,
      'FoodQty': foodQty,
    }.withoutNulls,
  );

  return firestoreData;
}

class SurveyFoodItemRecordDocumentEquality
    implements Equality<SurveyFoodItemRecord> {
  const SurveyFoodItemRecordDocumentEquality();

  @override
  bool equals(SurveyFoodItemRecord? e1, SurveyFoodItemRecord? e2) {
    return e1?.foodItem == e2?.foodItem && e1?.foodQty == e2?.foodQty;
  }

  @override
  int hash(SurveyFoodItemRecord? e) =>
      const ListEquality().hash([e?.foodItem, e?.foodQty]);

  @override
  bool isValidKey(Object? o) => o is SurveyFoodItemRecord;
}
