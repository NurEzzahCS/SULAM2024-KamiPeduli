import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NGOlistRecord extends FirestoreRecord {
  NGOlistRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "ngo" field.
  String? _ngo;
  String get ngo => _ngo ?? '';
  bool hasNgo() => _ngo != null;

  // "ngoEmail" field.
  String? _ngoEmail;
  String get ngoEmail => _ngoEmail ?? '';
  bool hasNgoEmail() => _ngoEmail != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  void _initializeFields() {
    _ngo = snapshotData['ngo'] as String?;
    _ngoEmail = snapshotData['ngoEmail'] as String?;
    _userRef = snapshotData['userRef'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('NGOlist');

  static Stream<NGOlistRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => NGOlistRecord.fromSnapshot(s));

  static Future<NGOlistRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => NGOlistRecord.fromSnapshot(s));

  static NGOlistRecord fromSnapshot(DocumentSnapshot snapshot) =>
      NGOlistRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static NGOlistRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      NGOlistRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'NGOlistRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is NGOlistRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createNGOlistRecordData({
  String? ngo,
  String? ngoEmail,
  DocumentReference? userRef,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'ngo': ngo,
      'ngoEmail': ngoEmail,
      'userRef': userRef,
    }.withoutNulls,
  );

  return firestoreData;
}

class NGOlistRecordDocumentEquality implements Equality<NGOlistRecord> {
  const NGOlistRecordDocumentEquality();

  @override
  bool equals(NGOlistRecord? e1, NGOlistRecord? e2) {
    return e1?.ngo == e2?.ngo &&
        e1?.ngoEmail == e2?.ngoEmail &&
        e1?.userRef == e2?.userRef;
  }

  @override
  int hash(NGOlistRecord? e) =>
      const ListEquality().hash([e?.ngo, e?.ngoEmail, e?.userRef]);

  @override
  bool isValidKey(Object? o) => o is NGOlistRecord;
}
