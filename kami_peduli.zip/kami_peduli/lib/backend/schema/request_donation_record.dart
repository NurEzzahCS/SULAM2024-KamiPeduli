import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RequestDonationRecord extends FirestoreRecord {
  RequestDonationRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "RequestName" field.
  String? _requestName;
  String get requestName => _requestName ?? '';
  bool hasRequestName() => _requestName != null;

  // "RequestItem" field.
  List<String>? _requestItem;
  List<String> get requestItem => _requestItem ?? const [];
  bool hasRequestItem() => _requestItem != null;

  // "RequestQty" field.
  List<int>? _requestQty;
  List<int> get requestQty => _requestQty ?? const [];
  bool hasRequestQty() => _requestQty != null;

  // "RequestTime" field.
  DateTime? _requestTime;
  DateTime? get requestTime => _requestTime;
  bool hasRequestTime() => _requestTime != null;

  // "Status" field.
  bool? _status;
  bool get status => _status ?? false;
  bool hasStatus() => _status != null;

  // "CollectionPoint" field.
  String? _collectionPoint;
  String get collectionPoint => _collectionPoint ?? '';
  bool hasCollectionPoint() => _collectionPoint != null;

  // "CollectionTime" field.
  String? _collectionTime;
  String get collectionTime => _collectionTime ?? '';
  bool hasCollectionTime() => _collectionTime != null;

  // "NGO" field.
  String? _ngo;
  String get ngo => _ngo ?? '';
  bool hasNgo() => _ngo != null;

  // "Confirmed" field.
  bool? _confirmed;
  bool get confirmed => _confirmed ?? false;
  bool hasConfirmed() => _confirmed != null;

  void _initializeFields() {
    _requestName = snapshotData['RequestName'] as String?;
    _requestItem = getDataList(snapshotData['RequestItem']);
    _requestQty = getDataList(snapshotData['RequestQty']);
    _requestTime = snapshotData['RequestTime'] as DateTime?;
    _status = snapshotData['Status'] as bool?;
    _collectionPoint = snapshotData['CollectionPoint'] as String?;
    _collectionTime = snapshotData['CollectionTime'] as String?;
    _ngo = snapshotData['NGO'] as String?;
    _confirmed = snapshotData['Confirmed'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('RequestDonation');

  static Stream<RequestDonationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RequestDonationRecord.fromSnapshot(s));

  static Future<RequestDonationRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RequestDonationRecord.fromSnapshot(s));

  static RequestDonationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RequestDonationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RequestDonationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RequestDonationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RequestDonationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RequestDonationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRequestDonationRecordData({
  String? requestName,
  DateTime? requestTime,
  bool? status,
  String? collectionPoint,
  String? collectionTime,
  String? ngo,
  bool? confirmed,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'RequestName': requestName,
      'RequestTime': requestTime,
      'Status': status,
      'CollectionPoint': collectionPoint,
      'CollectionTime': collectionTime,
      'NGO': ngo,
      'Confirmed': confirmed,
    }.withoutNulls,
  );

  return firestoreData;
}

class RequestDonationRecordDocumentEquality
    implements Equality<RequestDonationRecord> {
  const RequestDonationRecordDocumentEquality();

  @override
  bool equals(RequestDonationRecord? e1, RequestDonationRecord? e2) {
    const listEquality = ListEquality();
    return e1?.requestName == e2?.requestName &&
        listEquality.equals(e1?.requestItem, e2?.requestItem) &&
        listEquality.equals(e1?.requestQty, e2?.requestQty) &&
        e1?.requestTime == e2?.requestTime &&
        e1?.status == e2?.status &&
        e1?.collectionPoint == e2?.collectionPoint &&
        e1?.collectionTime == e2?.collectionTime &&
        e1?.ngo == e2?.ngo &&
        e1?.confirmed == e2?.confirmed;
  }

  @override
  int hash(RequestDonationRecord? e) => const ListEquality().hash([
        e?.requestName,
        e?.requestItem,
        e?.requestQty,
        e?.requestTime,
        e?.status,
        e?.collectionPoint,
        e?.collectionTime,
        e?.ngo,
        e?.confirmed
      ]);

  @override
  bool isValidKey(Object? o) => o is RequestDonationRecord;
}
