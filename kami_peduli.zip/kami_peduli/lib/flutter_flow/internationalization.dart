import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'ms'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? msText = '',
  }) =>
      [enText, msText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // a-Login
  {
    'o07j3mgv': {
      'en': 'Welcome back',
      'ms': 'Selamat Datang',
    },
    'fzxvw3mu': {
      'en': 'Login to access your account',
      'ms': 'Log masuk untuk mengakses akaun anda ',
    },
    'a9j78va9': {
      'en': 'Email Address',
      'ms': 'Alamat emel',
    },
    'i7f18cve': {
      'en': 'Enter your email...',
      'ms': 'Masukkan emel anda...',
    },
    'wztjmbn8': {
      'en': 'Password',
      'ms': 'Kata laluan',
    },
    'lw1jpm1f': {
      'en': 'Enter your password...',
      'ms': 'Masukkan kata laluan anda...',
    },
    'm2xyjvuf': {
      'en': 'Forgot Password?',
      'ms': 'Lupa kata laluan?',
    },
    'uixqdfhg': {
      'en': 'Login',
      'ms': 'Log masuk',
    },
    'cjqb8ial': {
      'en': 'Don\'t have an account?',
      'ms': 'Tiada akaun?',
    },
    'a0iimirx': {
      'en': 'Create',
      'ms': 'Cipta',
    },
    '2bb3vct7': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // a-Register
  {
    'gpokmd81': {
      'en': 'Get Started',
      'ms': 'Mula',
    },
    'oitrrwgg': {
      'en': 'Create your account below.',
      'ms': 'Cipta akaun anda di bawah',
    },
    'gcwdqm4g': {
      'en': 'Email Address',
      'ms': 'Alamat emel',
    },
    'iam0xgwx': {
      'en': 'Enter your email...',
      'ms': 'Masukkan emel anda...',
    },
    'bqv15dcf': {
      'en': 'Password',
      'ms': 'Kata laluan',
    },
    'joih97mn': {
      'en': 'Enter your password...',
      'ms': 'Masukkan kata laluan anda...',
    },
    'rzpiwq9p': {
      'en': 'Confirm Password',
      'ms': 'Mengesahkan kata laluan',
    },
    'eyfkffka': {
      'en': 'Enter your password...',
      'ms': 'Masukkan kata laluan anda...',
    },
    'nknacgkx': {
      'en': '',
      'ms': '',
    },
    '5kmjfwsk': {
      'en': 'Create Account',
      'ms': 'Cipta akaun',
    },
    '3twynvfz': {
      'en': 'Login',
      'ms': 'Log masuk',
    },
    '9ssznj0g': {
      'en': 'Already have an account?',
      'ms': 'Sudah mempunyai akaun?',
    },
    'momge5oj': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // a-CompleteProfile
  {
    'yhcaf7r2': {
      'en': 'Complete Profile',
      'ms': 'Profil lengkap',
    },
    '21sgh27n': {
      'en': 'Your Name',
      'ms': 'Nama anda ',
    },
    '2sxeqsj3': {
      'en': 'KPJ Resident',
      'ms': 'Residen KPJ',
    },
    'virkyncw': {
      'en': 'KPJ Leader',
      'ms': 'Ketua KPJ',
    },
    'yk2mw28t': {
      'en': 'NGO',
      'ms': 'NGO',
    },
    '72ii0waq': {
      'en': 'Your Title',
      'ms': 'Jenis pengguna',
    },
    'ue2wmnyi': {
      'en': 'Search for an item...',
      'ms': 'Cari item',
    },
    'hbhd3bdt': {
      'en': 'Login',
      'ms': 'Log masuk',
    },
    'sdptn7dd': {
      'en': '',
      'ms': '',
    },
    '1eac148w': {
      'en': 'Field is required',
      'ms': '',
    },
    'ew7dbn3s': {
      'en': 'Field is required',
      'ms': '',
    },
    'jhhlgzk5': {
      'en': 'Field is required',
      'ms': '',
    },
    '4k3jnl38': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // a-ForgotPassword
  {
    'g416xg9f': {
      'en': 'Forgot Password',
      'ms': 'Lupa kata laluan',
    },
    'xaiad71o': {
      'en':
          'Enter the email associated with your account and we will send you a verification code.',
      'ms':
          'Masukkan emel yang dikaitkan dengan akaun anda dan kami akan menghantar kod pengesahan kepada anda.',
    },
    'u4nuk910': {
      'en': 'Email Address',
      'ms': 'Alamat emel',
    },
    '37kotxi0': {
      'en': 'Enter your email...',
      'ms': 'Masukkan emel anda...',
    },
    'hiwpaze1': {
      'en': 'Send Reset Link',
      'ms': 'Hantar Pautan Tetapan Semula',
    },
    '598b8d3m': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // User1-Dashboard
  {
    'xn2so8km': {
      'en': 'Dashboard',
      'ms': 'Papan Pemuka',
    },
    'rud5kxee': {
      'en': 'Welcome,',
      'ms': 'Selamat Datang,',
    },
    'd2l37ke1': {
      'en': 'Your account details ',
      'ms': 'Butiran akaun anda',
    },
    '8bnd6lco': {
      'en': 'Collection Points',
      'ms': 'Pusat Kutipan',
    },
    'roobc02h': {
      'en': 'Survey',
      'ms': 'Profil',
    },
    '27pb7ji4': {
      'en': 'Collection Points',
      'ms': 'Pusat Kutipan',
    },
    'm8rhanhc': {
      'en': '•',
      'ms': '',
    },
  },
  // a-Profile
  {
    'f1bvbey3': {
      'en': 'My Account',
      'ms': 'Akaun Saya',
    },
    'i61y9ibx': {
      'en': 'Edit Profile',
      'ms': 'Sunting Profil',
    },
    '03k0vw86': {
      'en': 'Change Password',
      'ms': 'Ubah Kata Laluan',
    },
    '6w6wv95p': {
      'en': 'Notification Settings',
      'ms': 'Tetapan Pemberitahuan',
    },
    'eojlfs66': {
      'en': 'Privacy Policy',
      'ms': 'Kenyataan Privasi',
    },
    '2ll42t1u': {
      'en': 'Dark Mode',
      'ms': 'Mod Gelap',
    },
    '8d386226': {
      'en': 'Light Mode',
      'ms': 'Mod Cerah',
    },
    'rfxti0jd': {
      'en': 'Profile',
      'ms': 'Profil',
    },
    '8srr2k0j': {
      'en': '•',
      'ms': '.',
    },
  },
  // User3-DonationSent
  {
    'xf8d4sm8': {
      'en': 'Donation Sent!',
      'ms': 'Derma dihantar!',
    },
    'wrbg19ed': {
      'en': 'Okay',
      'ms': 'Baik',
    },
    'ndkybnrt': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // User2-SendRequest
  {
    'wv1862li': {
      'en': 'Confirm Accept Req',
      'ms': 'Sahkan terima permintaan',
    },
    'wwjahvpl': {
      'en': 'Office Budget',
      'ms': 'Bajet Pejabat',
    },
    'sx0vvzxd': {
      'en': 'External Transfer',
      'ms': 'Pemindahan luar',
    },
    'ai453kej': {
      'en': 'ACH Payment',
      'ms': 'Pembayaran ACH',
    },
    'wo9cebk7': {
      'en': 'Select Place',
      'ms': 'Pilih lokasi',
    },
    'rcevwwju': {
      'en': 'Reason',
      'ms': 'Sebab',
    },
    'uvrt7im0': {
      'en': 'Request Funds',
      'ms': 'Permintaan dana',
    },
    '7y89msg9': {
      'en': 'Tap above to complete request',
      'ms': 'Tekan diatas untuk melengkapkan permintaan',
    },
    'xk0bwox3': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // a-EditProfile
  {
    '4rzqov3y': {
      'en': 'Edit Profile',
      'ms': 'Sunting Profil',
    },
    '3p9y21e2': {
      'en': 'Your Name',
      'ms': 'Nama Anda',
    },
    'dw9gmjdc': {
      'en': 'Please enter a valid number...',
      'ms': 'Sila masukkan nombor yang sah...',
    },
    'z4fstn5l': {
      'en': 'Email Address',
      'ms': 'Alamat emel',
    },
    'jozgvwyg': {
      'en': 'Your email',
      'ms': 'Emel anda',
    },
    'i6edcl52': {
      'en': 'Save Changes',
      'ms': 'Simpan Perubahan',
    },
    '8cpdublq': {
      'en': 'Delete Profile',
      'ms': 'Padam Profil',
    },
    '59naq8ur': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // a-ChangePassword
  {
    'l5iggwaz': {
      'en': 'Change Password',
      'ms': 'Tukar kata laluan',
    },
    '2b97u8y5': {
      'en':
          'Enter the email associated with your account and we will send you link to reset your password.',
      'ms':
          'Masukkan emel yang dikaitkan dengan akaun anda dan kami akan menghantar pautan kepada anda untuk menetapkan semula kata laluan anda.',
    },
    'ajy1c3r9': {
      'en': 'Email Address',
      'ms': 'Alamat emel',
    },
    'hsqfoxya': {
      'en': 'Enter your email...',
      'ms': 'Masukkan emel anda',
    },
    'if4pz6lm': {
      'en': 'Send Reset Link',
      'ms': 'Hantar Pautan Tetapan Semula',
    },
    '5tvk9lv0': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // a-NotificationSetting
  {
    'sc4ff4ce': {
      'en': 'Notifications',
      'ms': 'Notifikasi',
    },
    'r72zvrv5': {
      'en':
          'Choose what notifcations you want to receive below and we will update the settings.',
      'ms':
          'Pilih pemberitahuan yang anda mahu terima di bawah dan kami akan mengemas kini tetapan.',
    },
    'gjygkr0n': {
      'en': 'Push Notifications',
      'ms': 'Pemberitahuan Tolak',
    },
    '3y3yhxbk': {
      'en':
          'Receive Push notifications from our application on a semi regular basis.',
      'ms':
          'Terima pemberitahuan tolak daripada aplikasi kami secara separa tetap.',
    },
    '1ytebj35': {
      'en': 'Email Notifications',
      'ms': 'Pemberitahuan Emel',
    },
    '9lvh5nst': {
      'en':
          'Receive email notifications from our marketing team about new features.',
      'ms':
          'Terima pemberitahuan emel daripada pasukan pemasaran kami tentang ciri baharu.',
    },
    '69d2j74u': {
      'en': 'Location Services',
      'ms': 'Perkhidmatan Lokasi',
    },
    '3k8cuv0d': {
      'en':
          'Allow us to track your location, this helps keep track of spending and keeps you safe.',
      'ms':
          'Benarkan kami menjejak lokasi anda, ini membantu menjejaki perbelanjaan dan memastikan anda selamat.',
    },
    'isgrgbfs': {
      'en': 'Save Changes',
      'ms': 'Simpan Perubahan',
    },
    'a96mlyeh': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // a-PrivacyPolicy
  {
    'alczfiiy': {
      'en': 'Privacy Policy',
      'ms': 'Polisi Privasi',
    },
    'fvsfg5on': {
      'en': 'How we use your data',
      'ms': 'Cara kami menggunakan data anda',
    },
    'nbiyrnzl': {
      'en':
          '1. KamiPeduli reserves the right to use all data and personal information given by the user for the purpose of its business purpose which includes any sharing on information to organization related with KitaPeduli, activities and testimonials uploaded for publicity.\n\n2. KamiPeduli is not responsible for any treatment of neither your personal data nor the content or security of other websites that this website may link to.\n\n3. All users and NGO (fundraisers) are responsible for the accuracy and completeness of their personal data and information. \n\n4. KamiPeduli will not be held responsible for any false information provided by users and fundraisers after due diligence is taken.\n\n5. A signing up as NGO (fundraiser) is not entitled to sponsor any other NGO in KitaPeduli.\n\n6. KPJ Residents, KPJ Leaders and NGO (fundraisers) may have the right to request copies of certain of your personal information that is within our custody.\n\n7. If any of the information held by us is inaccurate, you may request to be corrected.\n\n8. KamiPeduli reserves the right at its own discretion, without prior notice to suspend, permanently deny or terminate your access to KamiPeduli’s website if you are found to breach any of the terms and conditions including where there is any actual or suspected fraudulent, criminal or improper use of the website or associated service. Any fund received before the termination shall be handled by KamiPeduli accordingly as required by law.',
      'ms':
          '1. KamiPeduli mempunyai hak untuk menggunakan semua data dan maklumat peribadi yang diberikan oleh pengguna untuk tujuan perniagaan termasuk berkongsi maklumat kepada organisasi yang berkaitan dengan KamiPeduli, aktiviti dan testimoni yang dimuat naik untuk publisiti.\n2. KamiPeduli tidak bertanggungjawab terhadap sebarang perlakuan terhadap data peribadi anda atau kandungan atau keselamatan laman web lain yang laman web ini mungkin berhubung dengan.\n3. Semua pengguna dan NGO  bertanggungjawab terhadap ketepatan dan kelengkapan data peribadi dan maklumat mereka.\n4. KamiPeduli tidak akan bertanggungjawab atas sebarang maklumat palsu yang diberikan oleh pengguna dan penyumbang dana selepas pengambilan langkah berjaga-jaga.\n5. Mendaftar sebagai NGO (penyumbang dana) tidak dibenarkan untuk menaja mana-mana NGO lain di KamiPeduli.\n6. Penduduk KPJ, Pemimpin KPJ dan NGO   mempunyai hak untuk meminta salinan tertentu maklumat peribadi anda yang berada dalam kawalan kami.\n7. Sekiranya mana-mana maklumat yang dipegang oleh kami adalah tidak tepat, anda boleh meminta untuk dikemaskini.\n8. KamiPeduli mempunyai hak sendiri untuk menangguhkan tanpa notis, menafikan secara kekal atau menghentikan akses anda ke laman web KamiPeduli jika anda didapati melanggar mana-mana terma dan syarat termasuk jika terdapat sebarang penggunaan yang sebenarnya atau disyaki menipu, jenayah atau penggunaan laman web tidak betul atau mana-mana perkhidmatan yang berkaitan. Mana-mana dana yang diterima sebelum penghentian akan ditangani oleh KamiPeduli sebagaimana yang diperlukan oleh ketetapan undang-undang.',
    },
    'oks4x95o': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // User3-Dashboard
  {
    'msss152z': {
      'en': 'Dashboard',
      'ms': 'Papan Pemuka',
    },
    'py508ti2': {
      'en': 'Welcome,',
      'ms': 'Selamat datang,',
    },
    'ajkyllp3': {
      'en': 'Your account details ',
      'ms': 'Butiran akaun anda ',
    },
    '03rdn7n7': {
      'en': 'Approve Requests',
      'ms': 'Terima Permintaan',
    },
    'r87iuxmb': {
      'en': 'Confirm Send',
      'ms': 'Sahkan Penghantaran',
    },
    'hfcp6e8k': {
      'en': 'Pending Requests',
      'ms': 'Permintaan Tertunda',
    },
    'f04xsqk0': {
      'en': '•',
      'ms': '.',
    },
  },
  // User2-CreateRequest
  {
    '769f1uks': {
      'en': 'Create Donation Request',
      'ms': 'Hasilkan permintaan derma',
    },
    '94hn34n4': {
      'en': 'Request Name',
      'ms': 'Nama permintaan',
    },
    'g89r112m': {
      'en': 'Enter request name...',
      'ms': 'Masukkan nama permintaan...',
    },
    '29blr4m9': {
      'en': 'Item',
      'ms': 'Barang',
    },
    '21lbywtd': {
      'en': 'Enter item...',
      'ms': 'Masukkan barang...',
    },
    'obq0x7gf': {
      'en': 'Quantity',
      'ms': 'Bilangan',
    },
    'ymujwii3': {
      'en': 'Quantity',
      'ms': 'Bilangan',
    },
    'dobpdibt': {
      'en': 'Create',
      'ms': 'Cipta',
    },
  },
  // User2-Dashboard
  {
    '57yx347x': {
      'en': 'Dashboard',
      'ms': 'Papan Pemuka',
    },
    '1mob8nlp': {
      'en': 'Welcome,',
      'ms': 'Selamat Datang,',
    },
    'lu58pvqq': {
      'en': 'Your account details ',
      'ms': 'Butiran akaun anda',
    },
    '5np135u4': {
      'en': 'Survey Summary',
      'ms': 'Hasil Survey',
    },
    'q3epvcox': {
      'en': 'Create Requests',
      'ms': 'Cipta Permintaan',
    },
    'pwsc89me': {
      'en': 'See Requests',
      'ms': 'Lihat Permintaan',
    },
    'zx20zyoo': {
      'en': 'Approved Requests',
      'ms': 'Permintaan Diterima',
    },
    'enqi5q3f': {
      'en': '•',
      'ms': '.',
    },
  },
  // User2-OldRequestLists
  {
    'pkjxicyh': {
      'en': 'Requested Time:',
      'ms': 'Masa permintaan:',
    },
    't89bakg8': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'gza6tpno': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'gvg280sk': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'qpt1iq0b': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'w5r7umvo': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'zyamksdh': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'q539m8r6': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'urwq6mxo': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'sk5kq9pf': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'g2qj7d7r': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    '4mxqinhc': {
      'en': 'Donation Requests',
      'ms': 'Permintaan derma',
    },
    'lqqbg3cj': {
      'en': '•',
      'ms': '.',
    },
  },
  // User2-RequestDetails
  {
    '0m34tv0x': {
      'en': 'Donation Request Detail',
      'ms': 'Butiran Permintaan Sumbangan',
    },
    'w1qyti85': {
      'en': 'Requested Time',
      'ms': 'Masa Permintaan',
    },
    'pc2c79hk': {
      'en': 'Item List',
      'ms': 'Senarai Barangan',
    },
    'lspowa6y': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // User3-PendingDetails
  {
    'ciswazbi': {
      'en': ' Pending Request Detail',
      'ms': 'Butiran Permintaan Derma',
    },
    'p2dk6dlw': {
      'en': 'Requested Time',
      'ms': 'Masa Permintaan',
    },
    '2e4fosuh': {
      'en': 'Item List',
      'ms': 'Senarai Barangan',
    },
    'yy1q8sf2': {
      'en': 'Home',
      'ms': 'Halaman Utama',
    },
  },
  // User3-AcceptRequest
  {
    'klvd8mcs': {
      'en': 'Accept Request',
      'ms': 'Terima Permintaan',
    },
    '5n8hc3ns': {
      'en': 'Item List',
      'ms': 'Senarai Barangan',
    },
    'tnzax0x4': {
      'en': 'Accept',
      'ms': 'Terima',
    },
    'aldektuh': {
      'en': 'Tap above to accept request',
      'ms': 'Tekan diatas untuk menerima permintaan',
    },
    '97wmzpma': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User1-CollectionPointsList
  {
    'arpyfzc6': {
      'en': ' Collection Points',
      'ms': 'Pusat Pengumpulan',
    },
    'holh2xb0': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    '33ki2mau': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'eoiaq445': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    '2n78fead': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'tccyo3d7': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'w5nd3i28': {
      'en': 'Advertising Budget',
      'ms': 'Bajet Pengiklanan',
    },
    'gst6sg6j': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'rcsr0qko': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'bqhr8fs9': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'ckv8f8gx': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'ee498t5q': {
      'en': '•',
      'ms': '.',
    },
  },
  // User3-AcceptedRequest
  {
    'xxujy9f1': {
      'en': 'To Send',
      'ms': 'Belum Selesai',
    },
    'jvom7j2g': {
      'en': 'Requested Time:',
      'ms': 'Permintaan masa:',
    },
    '1dfk7t8e': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    '2kjwbyj7': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'rwdpjua8': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'ahyfhn1c': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'ul1qd5uq': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'smlddey4': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    '22prz7nj': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    '837t7817': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    '23qg8sci': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'i2urupbx': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'qhto5klu': {
      'en': 'Confirmed',
      'ms': 'Diluluskan',
    },
    'na21qgx6': {
      'en': 'Requested Time:',
      'ms': 'Permintaan masa:',
    },
    '9sq01sxg': {
      'en': 'Approved By:',
      'ms': 'Permintaan masa:',
    },
    'rtzgaos7': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    '8o87kdo0': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    '6rdsby8a': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'rotnkq5o': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'f218pvs8': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'oeitw5o3': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'lwybigx5': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    't11e2yav': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'oierx65j': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'j3hdg1ml': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    '3jnvt4v6': {
      'en': 'Accepted Requests',
      'ms': 'Terima permintaan',
    },
    'gsoku4t7': {
      'en': '•',
      'ms': '.',
    },
  },
  // User3-SendDonation
  {
    'jhvkblf9': {
      'en': 'Donation Request Detail',
      'ms': 'Butiran permintaan Sumbangan',
    },
    'vtx3owo1': {
      'en': 'Masjid As-Solihin',
      'ms': 'Masjid As-Solihin',
    },
    'pmjkrbsn': {
      'en': 'Balai Raya Kg. Padang Jawa',
      'ms': 'Balai Raya Kg. Padang Jawa',
    },
    'b8778b5n': {
      'en': 'Sk. Padang Jawa',
      'ms': 'Sk. Padang Jawa',
    },
    'yh16jfez': {
      'en': 'Collection Point',
      'ms': 'Pusat pengumpulan',
    },
    'cdsc0na1': {
      'en': 'Estimated Donation Delivery Time',
      'ms': 'Anggaran Masa Penghantaran Derma',
    },
    'mpgp09u2': {
      'en': 'Item List',
      'ms': 'Senarai barangan',
    },
    '7v92ypwk': {
      'en': 'Send Confirmation',
      'ms': 'Sahkan penghantaran',
    },
    'a5r61ueq': {
      'en': 'Tap above to complete transfer',
      'ms': 'Tekan di atas untuk menyelesaikan pemindahan.',
    },
    'fpw17eky': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User1-DonationDetails
  {
    'pmzepbvh': {
      'en': 'Donation Request Detail',
      'ms': 'Butiran permintaan sumbangan',
    },
    'kixgmk61': {
      'en': 'Estimated Time:',
      'ms': 'Anggaran masa',
    },
    'aqu2vecj': {
      'en': 'Item List',
      'ms': 'Senarai barangan',
    },
    'dmydwuf9': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User2-RequestLists
  {
    'fcw8e06q': {
      'en': 'All',
      'ms': 'Semua',
    },
    '69aibvy7': {
      'en': 'Requested Time:',
      'ms': 'Permintaan masa:',
    },
    '2jrv7l6r': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'zgdk565x': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'pi4xwtxy': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'jfy7440p': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'll0al91f': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'tg63p0bg': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'cpht3a3g': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    '6okr0gs8': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'fexhh9il': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    '7un2neka': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'vmqzpdr6': {
      'en': 'Pending',
      'ms': 'Belum selesai',
    },
    'm1k3j31m': {
      'en': 'Requested Time:',
      'ms': 'Permintaan masa:',
    },
    'y0iwi5oh': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'trvtwmj4': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'd6zyo9o3': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    't4jzyxz5': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    '19vf8l3k': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    '03q4t4fh': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'v9ojgcti': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    '01c2q7dr': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'x71nxmae': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'tzt1ndpy': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'p7xlrptc': {
      'en': 'Approved',
      'ms': 'Diluluskan',
    },
    'a6ngg43n': {
      'en': 'Requested Time:',
      'ms': 'Permintaan masa:',
    },
    '4a9pppee': {
      'en': 'Approved By:',
      'ms': 'Permintaan masa:',
    },
    'jznrdwac': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'znw7ojgv': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'y6b1rtbz': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    '8szw9i2g': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'bbedzdlb': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'kdwg7d19': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'uijnhxfn': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'c2kk0zgg': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    'ntjk6ngu': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'a2r4sxo2': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'hbk4azdf': {
      'en': 'Donation Requests',
      'ms': 'Permintaan sumbangan',
    },
    'qd62qc4j': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User1-Survey2
  {
    '07raw8az': {
      'en': 'Question 2/3',
      'ms': 'Soalan 2/3',
    },
    'wbpay46o': {
      'en': 'Food Item',
      'ms': 'Jenis makanan',
    },
    'r32rtjfs': {
      'en': 'Which of the food item below do you need?',
      'ms': 'Jenis makanan apakah yang anda perlukan?',
    },
    'diqe2ria': {
      'en': 'Next Question',
      'ms': 'Soalan seterusnya',
    },
    'ajyenjy8': {
      'en': 'Donation Survey',
      'ms': 'Kaji selidik sumbangan',
    },
    'lrzf6pgp': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User1-Survey3
  {
    '9molu8pa': {
      'en': 'Donation Survey',
      'ms': 'Kaji Selidik Sumbangan',
    },
    '93d47dmo': {
      'en': 'Question 3/3',
      'ms': 'Soalan 3/3',
    },
    '17sd9nxy': {
      'en': 'Essential Items',
      'ms': 'Barangan lain',
    },
    'i2bq0qxa': {
      'en': 'Which of the items below do you need?',
      'ms': 'Barangan xxx apa yang anda perlukan?',
    },
    'pa0jyaae': {
      'en': 'Finish Survey',
      'ms': 'Lengkapkan kaji selidik',
    },
    'vvg8lbyz': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User1-Survey1
  {
    'o6cpys0j': {
      'en': 'Donation Survey',
      'ms': 'Kaji Selidik Sumbangan',
    },
    'hgoe7m87': {
      'en': 'Question 1/3',
      'ms': 'Soalan 1/3',
    },
    'beuauzys': {
      'en':
          'This is to find a survey for donation request and will be sent to our community members for their valuable input.',
      'ms':
          'Ini adalah untuk mencari kaji selidik bagi permintaan sumbangan dan akan dihantar kepada ahli komuniti kami untuk pandangan mereka yang bermanfaat.',
    },
    'az8glc1m': {
      'en': 'How is your mood today ?',
      'ms': 'Bagaimana dengan kondisi anda hari ini?',
    },
    'k9c936lw': {
      'en': 'On a scale of 1 - 3 how are you feeling today?',
      'ms': 'Di skala 1 hingga 3, bagaimana perasaan anda hari ini?',
    },
    '7jzhh4la': {
      'en': 'Next Question',
      'ms': 'Soalan seterusnya',
    },
    'stax2xiv': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User2-SurveySummary
  {
    'bw0m4dnx': {
      'en': 'Survey Summary',
      'ms': 'Rumusan kaji selidik',
    },
    's5i4t90q': {
      'en': 'From Kampung Padang Jawa Residents',
      'ms': 'Dari penduduk Kampung Padang Jawa',
    },
    'm39naldq': {
      'en': 'Food Donation Items Needed',
      'ms': 'Barangan sumbangan makanan yang diperlukan',
    },
    'tc7zql1j': {
      'en': 'Essential Donation Items Needed',
      'ms': 'Barangan Sumbangan Pelbagai yang Diperlukan',
    },
    'zl8y2uie': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // User2-RequestList
  {
    'jxcsjjcq': {
      'en': ' Collection Points',
      'ms': 'Pusat Pengumpulan',
    },
    'uoi1i6c1': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'tuz8a8mk': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'oigvbvtn': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    '2rcs2kol': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'kqjuc3b9': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'lh8xba7t': {
      'en': 'Advertising Budget',
      'ms': 'Bajet Pengiklanan',
    },
    '2vp7lc2e': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'fi17nm09': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    '4d9z35ys': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    '24qpoh1v': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    '1li5qwhm': {
      'en': '•',
      'ms': '.',
    },
  },
  // User3-PendingLists
  {
    'jntk0epy': {
      'en': 'Pending Requests',
      'ms': 'Pusat Pengumpulan',
    },
    '9j0egne7': {
      'en': 'Request Time:',
      'ms': '',
    },
    '9inotgi9': {
      'en': 'Advertising Budget',
      'ms': 'Bajet pengiklanan',
    },
    'd45c4j3j': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'vygefdh5': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    '2yhiclbl': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'gmdmiiaa': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'btkaf9q4': {
      'en': 'Advertising Budget',
      'ms': 'Bajet Pengiklanan',
    },
    '66c0ym6i': {
      'en': 'RM 3,000',
      'ms': 'RM 3,000',
    },
    'unenzz6x': {
      'en': '4 Days Left',
      'ms': '4 hari lagi',
    },
    '7p95vihx': {
      'en': 'Total Spent',
      'ms': 'Jumlah perbelanjaan',
    },
    'voem52is': {
      'en': 'RM 2,502',
      'ms': 'RM 2,502',
    },
    'kpjm5qpv': {
      'en': '•',
      'ms': '.',
    },
  },
  // User3-SentDonation
  {
    'nmvdluxk': {
      'en': '   Sent Donation Detail',
      'ms': 'Butiran permintaan sumbangan',
    },
    'n7zw5sog': {
      'en': 'Requested Time:',
      'ms': 'Masa permintaan',
    },
    's53ompzs': {
      'en': 'Item List',
      'ms': 'Senarai barangan',
    },
    '2p09ukqj': {
      'en': 'Home',
      'ms': 'Halaman utama',
    },
  },
  // Miscellaneous
  {
    'lzyb73wy': {
      'en': '',
      'ms': '',
    },
    'kx9cdks4': {
      'en': '',
      'ms': '',
    },
    'efvtwj7k': {
      'en': '',
      'ms': '',
    },
    'ec5hfa1e': {
      'en': '',
      'ms': '',
    },
    'q5ljwvfo': {
      'en': '',
      'ms': '',
    },
    'j4rmwb3h': {
      'en': '',
      'ms': '',
    },
    '6ah1b18f': {
      'en': '',
      'ms': '',
    },
    '2kos1hen': {
      'en': '',
      'ms': '',
    },
    'v1dynw2j': {
      'en': '',
      'ms': '',
    },
    'f45gx7pm': {
      'en': '',
      'ms': '',
    },
    'j8wubv3d': {
      'en': '',
      'ms': '',
    },
    'vzpuub42': {
      'en': '',
      'ms': '',
    },
    '6obmcsp2': {
      'en': '',
      'ms': '',
    },
    'aox3s4fb': {
      'en': '',
      'ms': '',
    },
    'l8hv5a7z': {
      'en': '',
      'ms': '',
    },
    '4pjwb70a': {
      'en': '',
      'ms': '',
    },
    '0xlokf4y': {
      'en': '',
      'ms': '',
    },
    '8twlwiwt': {
      'en': '',
      'ms': '',
    },
    '35rezwmn': {
      'en': '',
      'ms': '',
    },
    'vzmquy6k': {
      'en': '',
      'ms': '',
    },
    '3xwo0odr': {
      'en': '',
      'ms': '',
    },
    'ud6zw5kq': {
      'en': '',
      'ms': '',
    },
    'a5x2ra1f': {
      'en': '',
      'ms': '',
    },
    'ety5khl2': {
      'en': '',
      'ms': '',
    },
    't4xzlq9q': {
      'en': '',
      'ms': '',
    },
    '513nj4m0': {
      'en': '',
      'ms': '',
    },
    'a1jxfgju': {
      'en': '',
      'ms': '',
    },
  },
].reduce((a, b) => a..addAll(b));
