import '/flutter_flow/flutter_flow_util.dart';
import 'user2_request_list_widget.dart' show User2RequestListWidget;
import 'package:flutter/material.dart';

class User2RequestListModel extends FlutterFlowModel<User2RequestListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
