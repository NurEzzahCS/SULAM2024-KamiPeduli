import '/flutter_flow/flutter_flow_util.dart';
import 'user2_create_request_widget.dart' show User2CreateRequestWidget;
import 'package:flutter/material.dart';

class User2CreateRequestModel
    extends FlutterFlowModel<User2CreateRequestWidget> {
  ///  Local state fields for this page.

  List<String> itemsRequested = [];
  void addToItemsRequested(String item) => itemsRequested.add(item);
  void removeFromItemsRequested(String item) => itemsRequested.remove(item);
  void removeAtIndexFromItemsRequested(int index) =>
      itemsRequested.removeAt(index);
  void insertAtIndexInItemsRequested(int index, String item) =>
      itemsRequested.insert(index, item);
  void updateItemsRequestedAtIndex(int index, Function(String) updateFn) =>
      itemsRequested[index] = updateFn(itemsRequested[index]);

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for requestName widget.
  FocusNode? requestNameFocusNode;
  TextEditingController? requestNameTextController;
  String? Function(BuildContext, String?)? requestNameTextControllerValidator;
  // State field(s) for RequestItem widget.
  FocusNode? requestItemFocusNode;
  TextEditingController? requestItemTextController;
  String? Function(BuildContext, String?)? requestItemTextControllerValidator;
  // State field(s) for RequestQty widget.
  FocusNode? requestQtyFocusNode;
  TextEditingController? requestQtyTextController;
  String? Function(BuildContext, String?)? requestQtyTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    requestNameFocusNode?.dispose();
    requestNameTextController?.dispose();

    requestItemFocusNode?.dispose();
    requestItemTextController?.dispose();

    requestQtyFocusNode?.dispose();
    requestQtyTextController?.dispose();
  }
}
