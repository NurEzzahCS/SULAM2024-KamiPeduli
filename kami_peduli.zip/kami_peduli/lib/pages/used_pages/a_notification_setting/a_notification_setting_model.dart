import '/flutter_flow/flutter_flow_util.dart';
import 'a_notification_setting_widget.dart' show ANotificationSettingWidget;
import 'package:flutter/material.dart';

class ANotificationSettingModel
    extends FlutterFlowModel<ANotificationSettingWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for SwitchListTile widget.
  bool? switchListTileValue1;
  // State field(s) for SwitchListTile widget.
  bool? switchListTileValue2;
  // State field(s) for SwitchListTile widget.
  bool? switchListTileValue3;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
