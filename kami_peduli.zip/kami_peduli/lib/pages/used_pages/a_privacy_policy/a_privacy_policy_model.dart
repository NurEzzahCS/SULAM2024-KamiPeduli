import '/flutter_flow/flutter_flow_util.dart';
import 'a_privacy_policy_widget.dart' show APrivacyPolicyWidget;
import 'package:flutter/material.dart';

class APrivacyPolicyModel extends FlutterFlowModel<APrivacyPolicyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
