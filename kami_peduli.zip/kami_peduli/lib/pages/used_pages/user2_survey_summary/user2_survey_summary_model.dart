import '/flutter_flow/flutter_flow_util.dart';
import 'user2_survey_summary_widget.dart' show User2SurveySummaryWidget;
import 'package:flutter/material.dart';

class User2SurveySummaryModel
    extends FlutterFlowModel<User2SurveySummaryWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
