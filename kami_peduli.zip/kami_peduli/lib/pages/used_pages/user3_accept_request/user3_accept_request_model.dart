import '/flutter_flow/flutter_flow_util.dart';
import 'user3_accept_request_widget.dart' show User3AcceptRequestWidget;
import 'package:flutter/material.dart';

class User3AcceptRequestModel
    extends FlutterFlowModel<User3AcceptRequestWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
