import '/flutter_flow/flutter_flow_util.dart';
import 'user1_donation_details_widget.dart' show User1DonationDetailsWidget;
import 'package:flutter/material.dart';

class User1DonationDetailsModel
    extends FlutterFlowModel<User1DonationDetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
