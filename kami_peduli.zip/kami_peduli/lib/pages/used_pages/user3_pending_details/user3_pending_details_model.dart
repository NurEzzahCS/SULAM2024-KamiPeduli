import '/flutter_flow/flutter_flow_util.dart';
import 'user3_pending_details_widget.dart' show User3PendingDetailsWidget;
import 'package:flutter/material.dart';

class User3PendingDetailsModel
    extends FlutterFlowModel<User3PendingDetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
