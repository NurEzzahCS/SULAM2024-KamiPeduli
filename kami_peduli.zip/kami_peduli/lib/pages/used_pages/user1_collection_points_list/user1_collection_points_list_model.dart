import '/flutter_flow/flutter_flow_util.dart';
import 'user1_collection_points_list_widget.dart'
    show User1CollectionPointsListWidget;
import 'package:flutter/material.dart';

class User1CollectionPointsListModel
    extends FlutterFlowModel<User1CollectionPointsListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
