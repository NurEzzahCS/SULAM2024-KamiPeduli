import '/flutter_flow/flutter_flow_util.dart';
import 'user2_dashboard_widget.dart' show User2DashboardWidget;
import 'package:flutter/material.dart';

class User2DashboardModel extends FlutterFlowModel<User2DashboardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
