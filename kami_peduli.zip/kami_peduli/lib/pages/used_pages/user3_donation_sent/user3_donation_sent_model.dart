import '/flutter_flow/flutter_flow_util.dart';
import 'user3_donation_sent_widget.dart' show User3DonationSentWidget;
import 'package:flutter/material.dart';

class User3DonationSentModel extends FlutterFlowModel<User3DonationSentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
