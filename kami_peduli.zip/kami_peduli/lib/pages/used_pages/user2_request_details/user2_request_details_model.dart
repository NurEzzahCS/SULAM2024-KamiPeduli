import '/flutter_flow/flutter_flow_util.dart';
import 'user2_request_details_widget.dart' show User2RequestDetailsWidget;
import 'package:flutter/material.dart';

class User2RequestDetailsModel
    extends FlutterFlowModel<User2RequestDetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
