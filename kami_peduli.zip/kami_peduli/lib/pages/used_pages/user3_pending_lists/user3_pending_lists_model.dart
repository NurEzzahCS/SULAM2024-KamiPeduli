import '/flutter_flow/flutter_flow_util.dart';
import 'user3_pending_lists_widget.dart' show User3PendingListsWidget;
import 'package:flutter/material.dart';

class User3PendingListsModel extends FlutterFlowModel<User3PendingListsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
