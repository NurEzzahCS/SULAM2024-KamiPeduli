import '/flutter_flow/flutter_flow_util.dart';
import 'user3_sent_donation_widget.dart' show User3SentDonationWidget;
import 'package:flutter/material.dart';

class User3SentDonationModel extends FlutterFlowModel<User3SentDonationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
