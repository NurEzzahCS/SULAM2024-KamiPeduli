import '/flutter_flow/flutter_flow_util.dart';
import 'user3_dashboard_widget.dart' show User3DashboardWidget;
import 'package:flutter/material.dart';

class User3DashboardModel extends FlutterFlowModel<User3DashboardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
