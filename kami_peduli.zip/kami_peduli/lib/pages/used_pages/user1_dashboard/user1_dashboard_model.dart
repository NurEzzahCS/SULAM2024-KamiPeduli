import '/flutter_flow/flutter_flow_util.dart';
import 'user1_dashboard_widget.dart' show User1DashboardWidget;
import 'package:flutter/material.dart';

class User1DashboardModel extends FlutterFlowModel<User1DashboardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
