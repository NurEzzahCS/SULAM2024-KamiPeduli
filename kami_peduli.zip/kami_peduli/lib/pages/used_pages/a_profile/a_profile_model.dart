import '/flutter_flow/flutter_flow_util.dart';
import 'a_profile_widget.dart' show AProfileWidget;
import 'package:flutter/material.dart';

class AProfileModel extends FlutterFlowModel<AProfileWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
