import '/flutter_flow/flutter_flow_util.dart';
import 'user2_old_request_lists_widget.dart' show User2OldRequestListsWidget;
import 'package:flutter/material.dart';

class User2OldRequestListsModel
    extends FlutterFlowModel<User2OldRequestListsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
