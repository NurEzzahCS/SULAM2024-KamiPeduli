package com.flutterflow.kamipeduli

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
